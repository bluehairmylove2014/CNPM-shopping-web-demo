Những Folder đã xóa để có thể nộp trên Moodle:
	+ node_modules: Có thể dùng 'npm install' để tải lại.
	+ assets: folder chứa ảnh cho web, vì quá nặng nên đã xóa. Có thể lấy lại trên
		Github và có thể xem web demo trên link.
Github và Link demo web đã được để trong trang cuối file Report.pdf